from flask import Flask, request, render_template
import pickle
import pandas as pd

app = Flask(__name__)

# Load the model
with open("model.pkl", "rb") as file:
    model = pickle.load(file)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Get input data from the form
    type = float(request.form['type'])
    amount = float(request.form['amount'])
    payerdebited = float(request.form['payerdebited'])
    recievercredited = float(request.form['recievercredited'])

    # Create a DataFrame from the input data
    input_data = pd.DataFrame({
        'type': [type],
        'amount': [amount],
        'payerdebited': [payerdebited],
        'recievercredited': [recievercredited]
    })

    # Ensure correct column order
    input_data = input_data[['type', 'amount', 'payerdebited', 'recievercredited']]

    # Make predictions
    prediction = model.predict(input_data)[0]
    probability = model.predict_proba(input_data)[0]

    # Prepare the result
    result = {
        'prediction': 'Non-Fraudulent' if prediction == 0 else 'Fraudulent',
        'probability_non_fraud': f"{probability[0] * 100:.2f}%",
        'probability_fraud': f"{probability[1] * 100:.2f}%"
    }

    # Render the template with the result
    return render_template('index.html', result=result)

if __name__ == '__main__':
    app.run(debug=True, port=5000)